# [Policy name]

**Version [1.0] · effective [date]**

> *Use this template for your `policy.md`. Replace every bracketed item and every italic instruction with your own content, and delete the instructions. For a completed example, see `FP2_Example_Verity/policy.md`. Your tiers, actions, and evidence types come from your domain. Do not copy Verity's.*

[One paragraph saying what this policy covers.]

> *Say what a case is in your domain (a listing, a report, a manifest), what parts it is made of, and when a case is reviewed against this policy.*

---

## Tiers and actions

| Tier | Class | Evidence needed to decide | Default action | Requires reviewer approval |
|---|---|---|---|---|
| T1 | [name] | [what the reviewer has to look at] | [action] | [Yes / No] |
| T2 | [name] | | | |
| T3 | [name] | | | |
| T4 | [name, or delete this row if you use three tiers] | | | |

> *Order the tiers from least to most serious. Check three things before you move on:*
> - *Each tier needs a different kind of evidence. If every tier can be decided by reading the case alone, change the tiers.*
> - *At least one tier needs a claim checked against an outside source.*
> - *The actions are graduated: there are options between allowing the case and blocking it.*

---

## T1 · [Class name]

**R1.1 · [Short rule name].** [What is required or prohibited, in one or two sentences.]

**R1.2 · [Short rule name].** [...]

## T2 · [Class name]

**R2.1 · [Short rule name].** [...]

## T3 · [Class name]

**R3.1 · [Short rule name].** [...]

## T4 · [Class name]

**R4.1 · [Short rule name].** [...]

> *Write 10 to 15 rules in total, spread across the tiers. Number each rule by its tier (R2.1, R2.2, ...). Your corpus and golden set refer to rules by these ids.*
>
> *Write each rule so that a reviewer could answer "is this rule broken?" with yes or no for a given case. "Claims must be accurate" is too vague to apply. "Any quantitative performance claim must cite a public source, and the claim must match the source" can be checked.*
>
> *If a rule has an exception, put the exception in the same rule rather than in a separate one.*

---

## How the rules are applied

1. **Several findings in one case.** [What happens when a case breaks more than one rule, for example: the case receives the action of its highest-tier finding.]
2. **[Any modifier, such as history.]** [Anything outside the case itself that changes how a finding is handled. Delete this item if you have none.]
3. **[A boundary you expect to come up.]** [Where two readings of a rule are both reasonable, say which one the policy intends. Your ambiguous cases will usually test these boundaries.]
4. **When the evidence does not settle a case.** [What happens when the evidence does not settle whether a rule is broken, for example: the case goes to a reviewer.]

---

## Change log

| Version | Date | Change |
|---|---|---|
| 1.0 | [date] | First version |

> *Add a row each time you change a rule, for example after your golden-set labelers disagree about one.*
