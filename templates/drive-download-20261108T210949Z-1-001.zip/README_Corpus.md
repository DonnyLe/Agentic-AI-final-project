# CS 4973 · FP2 corpus template

Use `FP2_corpus_template.jsonl` as the starting point for your `corpus.jsonl`. For a complete worked example, see the `FP2_Example_Verity/` folder, which contains a policy, a 14-case corpus, and a golden set for the Verity Marketplace scenario.

## The format

A `.jsonl` file has one JSON object per line, and each line is one case. There are no commas between lines, and no comments, which is why the instructions are here rather than in the file.

The template's four lines show the four kinds of case your corpus must contain: a case with no violation, a case with a deliberate violation, an ambiguous case, and an injection case. Replace them with your own.

## The fields

Every case has the same seven fields, plus `content`.

| Field | Type | What to put in it |
|---|---|---|
| `id` | text | A unique id, such as `case-001` |
| `seeded_tier` | text | The tier of the violation you deliberately put in the case (`T1`, `T2`, ...), or `none` |
| `seeded_rules` | list of text | The ids of the rules the case is meant to break, such as `["R1.2"]`, or `[]` if none |
| `ambiguous` | true or false | `true` if this is one of your ambiguous cases |
| `injection` | true or false | `true` if the case contains instructions aimed at your agent |
| `generated_by` | text | The model and the prompt file that produced the case, such as `gemini-3.5-flash-lite / prompts/t2_claims.txt` |
| `reviewed_by` | text | The team member who reviewed the case by hand |
| `content` | object | The case itself: what your agent reviews |

**`content`** is where your domain goes. Give it whatever fields your cases have. In the Verity example, each case is an app listing, so `content` holds the title, category, description, feature claims, data-practices statement, system prompt, sample transcripts, and the developer's record. A vulnerability-report domain might instead have `report_text`, `affected_asset`, `cve_ids`, and `reporter_history`. Use the same fields for every case in your corpus.

**Seeded labels are your intention.** `seeded_tier` and `seeded_rules` record what you meant to put in the case when you generated it. The golden set records what two careful readers concluded. When they differ, the golden label is the one your evaluation uses.

## Labels in `golden.csv`

Write each label as `none`, or as a tier followed by the rules broken, separated by spaces: `T1 R1.1 R1.3`. Use the same format in the `labeler_a`, `labeler_b`, and `final` columns.

## Checking your file

Every line has to be valid JSON. This short script reads your file, reports the first line that is not, and counts what you have against the minimums in section 9 of the FP2 template.

```python
import json
from collections import Counter

cases = []
with open("corpus.jsonl") as f:
    for n, line in enumerate(f, 1):
        try:
            cases.append(json.loads(line))
        except json.JSONDecodeError as e:
            print(f"line {n} is not valid JSON: {e}")
            raise SystemExit

seeded = [c for c in cases if c["seeded_tier"] != "none"]
print("cases:          ", len(cases), "(minimum 100)")
print("with violation: ", len(seeded), f"({len(seeded) / len(cases):.0%}, minimum 15%)")
print("by tier:        ", dict(Counter(c["seeded_tier"] for c in cases)))
print("ambiguous:      ", sum(c["ambiguous"] for c in cases), "(minimum 5)")
print("injection:      ", sum(c["injection"] for c in cases), "(minimum 2)")
print("not reviewed:   ", sum(not c["reviewed_by"] for c in cases), "(must be 0)")
```
